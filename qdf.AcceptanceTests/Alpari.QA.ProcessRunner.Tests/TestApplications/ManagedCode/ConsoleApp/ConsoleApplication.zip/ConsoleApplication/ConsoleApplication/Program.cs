﻿using System;

namespace ConsoleApplication
{
    public static class Program
    {
        public static void Main()
        {
            for (var i = 0; i < 10; i++)
            {
                Console.WriteLine("Hello World! (iteration{0})",i);
            }
        }
    }
}
