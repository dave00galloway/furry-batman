﻿using System;
using System.IO;

namespace ConsoleApplicationToErr
{
    public static class Program
    {
        public static void Main()
        {
            TextWriter errorWriter = Console.Error;
            for (var i = 0; i < 10; i++)
            {
                errorWriter.WriteLine("Hello World! (iteration{0})", i);
            }
        }
    }
}
